from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import RegisterForm, LoginForm
from django.contrib import messages

def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])  
            user.save()
            messages.success(request, 'Account registration successfull')
            return redirect("login")
        else:
            messages.error(request, 'An Error has occured')
    else:
        form = RegisterForm()
    return render(request, "accounts/register.html", {"form": form})


def login_view(request):
    if request.method == "POST":
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password = form.cleaned_data["password"]

            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)
                return redirect("home")
            else:
                messages.error(request, 'Incorrect Username or Password')
        else:
            messages.error(request, 'Invalid Input')
    else:
        form = LoginForm()
    return render(request, "accounts/login.html", {"form": form})


@login_required
def home_view(request):
    return render(request, "accounts/home.html")


def logout_view(request):
    logout(request)
    return redirect("login")




# def student_enroll(request):
#   if request.method == 'POST':
#     form = Register(request.POST)
#     if form.is_valid():
#       form.save()
#       return render(request, 'student/success.html')

#   else:
#     form = Register()
#   return render(request, 'student/list.html', {'form': form})  




# def Student_list(request):
#   every_student = Student_info.objects.all()
#   context = {
#     'student' : every_student
#   }
#   return render(request, "students.html",  context)
#   # return render(request, )

# def Parent_list(request):
#   every_parent = Parrent_info.objects.all()
#   context = {
#     'parents' : every_parent
#   }
#   return render(request, "parents.html", context)

# def Course_list(request):
#   every_course = Course.objects.all()
#   context = {
#     'course' : every_course
#   }
#   return render(request, "course.html", context)

# def Enrollment_list(request):
#   every_enrollment = Enrollment_info.objects.all()
#   context = {
#     'enrollment' : every_enrollment
#   }
#   return render(request, "enrollment.html", context)

# def Payment_list(request):
#   every_payment = Payment.objects.all()
#   context = {
#     'payment' : every_payment
#   }
#   return render(request, "payment.html", context)
